#  Utilities

Download the SubjectiveEye3D dataset here. The link: [https://s3.amazonaws.com/subjectiveEye/0.9/subjectiveEye3D/part-r-00000.gz](https://s3.amazonaws.com/subjectiveEye/0.9/subjectiveEye3D/part-r-00000.gz)

```bash
wget https://s3.amazonaws.com/subjectiveEye/0.9/subjectiveEye3D/part-r-00000.gz
gzip -d part-r-00000.gz
```
