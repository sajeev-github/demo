cd ../
cp -r qald_json ../../../../
cd ../../../../qald_json 
cp qald_json_gerbil_input.py ../
cp interpreter.py ../
echo "Files shifted to the main folder."