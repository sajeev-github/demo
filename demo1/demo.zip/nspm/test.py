import pandas as pd

file_name = "./data/art_30/neuralmt.pkl"
objects = pd.read_pickle(file_name)

print(objects)
